%% Preamble
% Clear the command window and remove variables from memory
clc; clearvars;

% Set working directory to that of current live script.
filepath = fileparts(matlab.desktop.editor.getActiveFilename);
cd(filepath);

% Add source code and external dependencies to current session's search path.
addpath(genpath('../source/'));

%% Generate grid of machine configurations
% Clear the command window and remove variables from memory
clc; clearvars;

% Machine configurations
pinRadiiRange = [2 10];
maxGearRadius = 50;
maxRotationAngle = 90;
strokeLengthRange = [5 50];

% Grid parameters
nPinRadii = 9;
nStrokeLengths = 46;
nRotationAngles = 91;

gridSize = [nRotationAngles nStrokeLengths nPinRadii];

% Generate stroke lengths over grid
strokeLengths = repmat(linspace(strokeLengthRange(1), strokeLengthRange(2), nStrokeLengths), [nRotationAngles 1]);

% Compute gear radii for all stroke lengths and valid rotation angles.
% Valid rotation angles are limited at the lower bound by the maximum gear
% radius, and the upper bound at 90 degrees.
gearRadii = nan([nRotationAngles nStrokeLengths]);
rotationAngles = nan([nRotationAngles nStrokeLengths]);
for j = 1 : nStrokeLengths
    % Find valid rotation angle range
    minRotationAngle = calculateTotalRotationAngle(maxGearRadius, strokeLengths(1, j));
    rotationAnglesTemp = linspace(minRotationAngle, maxRotationAngle, nRotationAngles)';

    % Evaluate corresponding gear radii
    gearRadiiTemp = nan(nRotationAngles, 1);
    for i = 1 : nRotationAngles
        gearRadiiTemp(i) = calculateGearRadius(rotationAnglesTemp(i), strokeLengths(i, j));
    end

    % Resample rotation angles and gear radii uniformly to improve grid
    % condition.
    temp0 = [rotationAnglesTemp gearRadiiTemp];
    dist = sqrt(sum((temp0(1 : end - 1, :) - temp0(2 : end, :)) .^ 2, 2));
    cdist = [0; cumsum(dist)];
    cdist = cdist ./ cdist(end);
    temp1 = interp1(cdist, temp0, linspace(0, 1, nRotationAngles), "linear");

    % Evaluate resampled gear radii
    rotationAngles(:, j) = temp1(:, 1);
    for i = 1 : nRotationAngles
        gearRadii(i, j) = calculateGearRadius(rotationAngles(i, j), strokeLengths(i, j));
    end
end

% Generate grid over all pin radii
pinRadii = nan([1 1 nPinRadii]);
pinRadii(:) = linspace(pinRadiiRange(1), pinRadiiRange(2), nPinRadii);
pinRadii = repmat(pinRadii, [nRotationAngles nStrokeLengths 1]);

strokeLengths = repmat(strokeLengths, [1 1 nPinRadii]);
gearRadii = repmat(gearRadii, [1 1 nPinRadii]);
rotationAngles = repmat(rotationAngles, [1 1 nPinRadii]);

% Save results
save("../data/data.mat", "strokeLengths", "rotationAngles", "gearRadii", "pinRadii");

% Plot results
figure('WindowStyle','docked'); hold on;
surf(squeeze(strokeLengths(:, :, 1)), squeeze(gearRadii(:, :, 1)), squeeze(rotationAngles(:, :, 1)), 'EdgeColor', 'black', 'FaceColor', 'blue', 'FaceAlpha', 0.5);
xlabel('strokeLengths'); ylabel('gearRadii'); zlabel('rotationAngles');
axis('square'); view([30 30]); grid on;
shg;

%% Compute cross shears
% Clear the command window and remove variables from memory
clc; clearvars;

% Load grid of machine configurations
load("../data/data.mat", "strokeLengths", "rotationAngles", "gearRadii", "pinRadii");
gridSize = size(strokeLengths);
nRotationAngles = gridSize(1);
nStrokeLengths = gridSize(2); 
nPinRadii = gridSize(3);

% Sampling parameters
period = 1;
nRings = 20; % was 20 for data_1
nTimeSteps = 50; % was 50 for data_1

% Generate samples on unit radius surface
unitSamples = generateRegularSamples(1, nRings);

% Compute cross shears for various pin radii
crossShears = nan(gridSize);
for i = 1 : nRotationAngles
    fprintf('%d of %d\n',i, nRotationAngles);
    for j = 1 : nStrokeLengths
        for k = 1 : nPinRadii
            samples = [unitSamples(:, 1) unitSamples(:, 2) .* pinRadii(i, j, k)];
            crossShears(i, j, k) = integrateCrossShear(strokeLengths(i, j, k), gearRadii(i, j, k), period, nTimeSteps, samples);
        end
    end
end

% Save result
save("../data/data.mat", "crossShears", "-append"); % Seems that the CS values dont append to the data.mat file

% Plot results
figure('WindowStyle','docked');
colors = jet(nPinRadii);
legendEntries = cellfun(@(x)sprintf("R_p %2.2f", x), num2cell(unique(pinRadii)));

subplot(1, 2, 1); hold on
for k = 1 : nPinRadii
    surf(squeeze(strokeLengths(:, :, k)), squeeze(rotationAngles(:, :, k)), squeeze(crossShears(:, :, k)), 'EdgeColor', 'black', 'FaceColor', colors(k, :), 'FaceAlpha', 0.5);
end
legend(legendEntries);
xlabel('strokeLengths'); ylabel('rotationAngles'); zlabel('crossShears');
axis('square'); view([30 30]); grid on;

subplot(1, 2, 2); hold on
for k = 1 : nPinRadii
    surf(squeeze(strokeLengths(:, :, k)), squeeze(gearRadii(:, :, k)), squeeze(crossShears(:, :, k)), 'EdgeColor', 'black', 'FaceColor', colors(k, :), 'FaceAlpha', 0.5);
end
legend(legendEntries);
xlabel('strokeLengths'); ylabel('gearRadii'); zlabel('crossShears');
axis('square'); view([30 30]); grid on;

shg;

%% Convert cross shear grid into table data
% Preamble
clc; clear;

% Load data
load("../data/data.mat", "strokeLengths", "rotationAngles", "gearRadii", "pinRadii", "crossShears");
gridSize = size(strokeLengths);

% Convert to table
columnNames = {'strokeLength', 'rotationAngle', 'gearRadius', 'pinRadius', 'crossShear'};
data = [reshape(strokeLengths, [], 1) reshape(rotationAngles, [], 1) reshape(gearRadii, [], 1) reshape(pinRadii, [], 1) reshape(crossShears, [], 1)];
table = array2table(data, 'VariableNames', columnNames);

% Save table
writetable(table, "../data/data.csv");

% Save grid size instructions
fid = fopen("../data/gridDetails.txt", "w");
fprintf(fid, "Rotation angle range: [%2.3f %2.3f]\n", min(rotationAngles(:)), max(rotationAngles(:)));
fprintf(fid, "Stroke length range:  [%2.3f %2.3f]\n", min(strokeLengths(:)), max(strokeLengths(:)));
fprintf(fid, "Gear radius range:    [%2.3f %2.3f]\n", min(gearRadii(:)), max(gearRadii(:)));
fprintf(fid, "Pin radius range:     [%2.3f %2.3f]\n", min(pinRadii(:)), max(pinRadii(:)));
fprintf(fid, "Grid size [nRotationAngles nStrokeLengths nPinRadii]: [%i %i %i]\n", gridSize);
fclose(fid);