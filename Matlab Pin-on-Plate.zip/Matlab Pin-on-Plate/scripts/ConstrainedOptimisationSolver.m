%% Preamble
% Clear the command window and remove variables from memory
clc; clearvars;

% Set working directory to that of current live script.
filepath = fileparts(matlab.desktop.editor.getActiveFilename);
cd(filepath);

% Add source code and external dependencies to current session's search path.
addpath(genpath('../source/'));

%% Compute cross shear for specified machine configuration using numerical integration
% Clear the command window and remove variables from memory
clc; clearvars;

% Machine configuration
strokeLength = 28;
rotationAngle = 30;
gearRadius = calculateGearRadius(rotationAngle, strokeLength);
pinRadius = 4;

% Sampling parameters
period = 1;
nRings = 20;
nTimeSteps = 50;

% Generate samples on pin surface
samples = generateRegularSamples(pinRadius, nRings);

% Compute cross shear
crossShear = integrateCrossShear(strokeLength, gearRadius, period, nTimeSteps, samples);

% Display results
fprintf("Gear radius: %2.3f \nCross shear: %2.3f \n", gearRadius, crossShear);

%% Optimize machine configuration for target cross shear value using numerical integration
% Clear the command window and remove variables from memory
clc; clearvars;

% Machine configurations
targetCrossShear = 0.03;    % Desired cross shear from literature, e.g. knee implant
initialStrokeLength = 10;   % Approximate from figure
strokeLengthRange = [10 25]; % Limit search range, e.g. from figure or available machine
initialPinRadius = 4;       % Approximate from figure
pinRadiusRange = [4 8];     % Limit search range, e.g. from figure or available machine
gearRadius = 25;            % Fixed, e.g. from available machine

% Sampling parameters
period = 1;
nRings = 20;
nTimeSteps = 50;

% Generate samples on unit radius pin surface
unitSamples = generateRegularSamples(1, nRings);

% Find stroke length and pin radius
lowerBound = [strokeLengthRange(1) pinRadiusRange(1)];
initialValues = [initialStrokeLength initialPinRadius];
upperBound = [strokeLengthRange(2) pinRadiusRange(2)];

objectiveFunction = @(x) (targetCrossShear - integrateCrossShear(x(1), gearRadius, period, nTimeSteps, [unitSamples(:, 1) unitSamples(:, 2) .* x(2)])) ^ 2;

% Solve for cross shear
options = optimset('Algorithm', 'interior-point', 'FinDiffType', 'central', 'Hessian', 'bfgs');
solution = fmincon(objectiveFunction, initialValues, [], [], [], [], lowerBound, upperBound, [], options);
strokeLength = solution(1);
pinRadius = solution(2);

% Evaluate cross shear at optimal machine configuration
crossShear = integrateCrossShear(strokeLength, gearRadius, period, nTimeSteps, [unitSamples(:, 1) unitSamples(:, 2) .* pinRadius]);

% Display results
fprintf("Pin radius: %2.3f\nStroke length: %2.3f\nCross shear: %2.3f\nGear radius: %2.3f\n", pinRadius, strokeLength, crossShear,gearRadius);

