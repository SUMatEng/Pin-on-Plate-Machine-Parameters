% Performs Monte Carlo numerical integration to determine the cross shear.
% Implemented from [beck2013, kang2008].
%
% Refereces:
%   [beck2012] Beck, M. M. "Customized knee implants: Evaluation and
%      qualification of materials and new manufacturing processes." (2012).
%   [kang2008] Kang, L., Galvin, A.L., Brown, T.D., Jin, Z. and Fisher, J.,
%       2008. Quantification of the effect of cross-shear on the wear of
%       conventional and highly cross-linked UHMWPE. Journal of biomechanics,
%       41(2), pp.340-346.

function crossShear = integrateCrossShear(strokeLength, gearRadius, period, nTimeSteps, samples)
    % Predefined variables
    halfPeriod = period / 2;
    nSamples = size(samples, 1);
 
    % Samples
    numerator = 0;
    denominator = 0;
    for i = 1 : nSamples
        for sampleTime = 0 : halfPeriod / nTimeSteps : halfPeriod
            % Polar coordinates of the current sample
            sampleAngle = samples(i, 1);
            sampleRadius = samples(i, 2);
    
            % Calculate sliding angle and velocity
            rotationAngle = calculateRotationAngle(strokeLength, gearRadius, period, sampleTime);
            [velocityX, velocityY] = calculateVelocity(period, gearRadius, rotationAngle, sampleTime, sampleAngle, sampleRadius);
            [localVelocityX, localVelocityY] = calculateLocalVelocity(rotationAngle, velocityX, velocityY);
            slidingAngle = calculateSlidingAngle(localVelocityX, localVelocityY);
    
            % Accumulate numerator and denominator
            numerator = numerator + sin(slidingAngle) * localVelocityY;
            denominator = denominator + sqrt(localVelocityX ^ 2 + localVelocityY ^ 2);
        end
    end

    % Calculate cross shear
    crossShear = numerator / denominator;
end

% Utility functions
function [velocityX, velocityY] = calculateVelocity(period, gearRadius, rotationAngle, sampleTime, sampleAngle, sampleRadius)
    theta = rotationAngle + sampleAngle;
    a = sin(2 * pi * sampleTime / period);
    b = sampleRadius / gearRadius;
    
    velocityX =  a * (1 + sin(theta) * b);
    velocityY = - cos(theta) * a * b;
end

function [localVelocityX, localVelocityY] = calculateLocalVelocity(rotationAngle, velocityX, velocityY)
    a = cos(rotationAngle);
    b = sin(rotationAngle);
    localVelocityX = a * velocityX + b * velocityY;
    localVelocityY = - b * velocityX + a * velocityY;
end

function rotationAngle = calculateRotationAngle(strokeLength, gearRadius, period, sampleTime) % phi
    rotationAngle = strokeLength * cos(2 * pi * sampleTime / period) / (2 * gearRadius);
end

function crossShearAngle = calculateSlidingAngle(localVelocityX, localVelocityY) % alpha
    % Use atan2, not atan, which gives incorrect results for cross shear
    % values closer to 0.5.
    crossShearAngle = atan2(localVelocityY, localVelocityX); 
end