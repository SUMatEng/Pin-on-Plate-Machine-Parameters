% Utility functions for converting between stroke length, gear radius and
% maximum rotation angle
function totalRotationAngle = calculateTotalRotationAngle(gearRadius, strokeLength)
    totalRotationAngle = strokeLength * 90 / (pi * gearRadius);
end