% Utility functions for converting between stroke length, gear radius and
% maximum rotation angle
function strokeLength = calculateStrokeLength(totalRotationAngle, gearRadius)
    strokeLength = gearRadius * pi * totalRotationAngle / 90;
end
