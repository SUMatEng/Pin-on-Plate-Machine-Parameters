% Utility functions for converting between stroke length, gear radius and
% maximum rotation angle
function gearRadius = calculateGearRadius(totalRotationAngle, strokeLength)
    gearRadius = strokeLength * 90 / (pi * totalRotationAngle);
end