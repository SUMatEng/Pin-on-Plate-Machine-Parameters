% Generates the polar coordinates of points sampled regularly on n number
% of rings placed in a circle. Inner rings have fewer samples proportional
% to its radius.
function samples = generateRegularSamples(outerRadius, nRings)
cnt = 1;
samples = nan(1, 2);
for radius = 0 : outerRadius / (nRings - 1) : outerRadius 
    nThetas = round((radius / outerRadius) * (nRings - 1) * 5);
    for theta = 0 : 2 * pi / nThetas : 2 * pi
        samples(cnt, :) = [theta, radius];
        cnt = cnt + 1;
    end
end

end